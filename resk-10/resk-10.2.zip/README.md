# resk

#### 介绍

慕课网3小时极简春节抢红包之Go的实战源代码



课程地址：https://www.imooc.com/learn/1101

resk: red envelope seckill（second kill） 
红包秒杀系统

