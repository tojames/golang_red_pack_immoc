package main

import (
	"fmt"
	"imooc.com/resk/infra/algo"
)

func main() {
	fmt.Println(algo.AfterShuffle(int64(10), int64(10000)))
}
